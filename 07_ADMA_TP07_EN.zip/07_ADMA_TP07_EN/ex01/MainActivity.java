package acc.com.capture;



import android.os.Bundle;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.provider.MediaStore;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.MediaController;
import android.widget.VideoView;
public class MainActivity extends AppCompatActivity {
  private ImageView imgCapture;
  private Button btnCaptureImage;
  private VideoView vidCapture;
  private Button btnCaptureVideo;
  private final static int ACTION_CAPTURE_IMAGE = 1;
  private final static int ACTION_CAPTURE_VIDEO = 2;
  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.activity_main);
    init();
  }
  private void init() {
    imgCapture = (ImageView) findViewById(R.id.imgCapture);
    btnCaptureImage = (Button) findViewById(R.id.btnCaptureImage);
    vidCapture = (VideoView) findViewById(R.id.vidCapture);
    MediaController mediaController = new
                    MediaController(this);
    mediaController.setAnchorView(vidCapture);
    vidCapture.setMediaController(mediaController);
    btnCaptureVideo = (Button) findViewById(R.id.btnCaptureVideo);
    ajouterEcouteur();
  }
  private void ajouterEcouteur() {
    btnCaptureImage.setOnClickListener(new OnClickListener() {
      @Override
      public void onClick(View arg0) {        capturerImage();      }
    });
    btnCaptureVideo.setOnClickListener(new OnClickListener() {
      @Override
      public void onClick(View arg0) {        capturerVideo();      }
    });
  }
  protected void capturerImage() {
    Intent i = new Intent(android.provider.MediaStore.ACTION_IMAGE_CAPTURE);
    startActivityForResult(i, ACTION_CAPTURE_IMAGE);
  }  
  protected void capturerVideo() {
    Intent takeVideoIntent = new Intent(MediaStore.ACTION_VIDEO_CAPTURE);
    startActivityForResult(takeVideoIntent, ACTION_CAPTURE_VIDEO);
  }
  @Override
  protected void onActivityResult(int requestCode, int resultCode, Intent data) {
    if (requestCode == ACTION_CAPTURE_IMAGE && resultCode == RESULT_OK) {
      Bundle extras = data.getExtras();
      Bitmap imageBitmap = (Bitmap) extras.get("data");
      imgCapture.setImageBitmap(imageBitmap);
    } else if (requestCode == ACTION_CAPTURE_VIDEO && resultCode == RESULT_OK) {
      Uri videoUri = data.getData();
      vidCapture.setVideoURI(videoUri);
      vidCapture.start();
    }
  }
}
