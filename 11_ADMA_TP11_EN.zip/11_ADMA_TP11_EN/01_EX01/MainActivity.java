package com.drone;

import androidx.appcompat.app.AppCompatActivity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {
    
    private EditText edDroite;
    private Button btnDroite;
	private EditText edGauche;
    private Button btnGauche;
	private EditText edHaut;
    private Button btnHaut;
	private EditText edBas;
    private Button btnBas;
	
   
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
    }

    private void init() {
        edDroite = findViewById(R.id.edDroite);
        btnDroite = findViewById(R.id.btnDroite);
		edGauche = findViewById(R.id.edGauche);
		btnGauche = findViewById(R.id.btnGauche);
		edHaut = findViewById(R.id.edHaut);
		btnHaut = findViewById(R.id.btnHaut);
		edBas = findViewById(R.id.edBas);
		btnBas = findViewById(R.id.btnBas);
        ajouterEcouteur();
    }

    private void ajouterEcouteur() {
       
    }

}
