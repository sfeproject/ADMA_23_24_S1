package com.mer;

import androidx.appcompat.app.AppCompatActivity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    public static final int IMG_MER_CALME = R.drawable.mer_calme;
    public static final int IMG_MER_AGITEE = R.drawable.mer_agitee;
    public static final int IMG_MER_TRES_AGITEE = R.drawable.mer_tres_agitee;
    private TextView tvEtat;
    private ImageView imgEtat;
   
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        init();
    }

    private void init() {
        tvEtat = findViewById(R.id.tvEtat);
        imgEtat = findViewById(R.id.imgEtat);
        ajouterEcouteur();
    }

    private void ajouterEcouteur() {
       
    }

    private void demarrerService() {
       
    }

    private void arreterService() {
      
    }

    @Override
    protected void onResume() {
       
        super.onResume();
    }

    @Override
    protected void onPause() {
       
        super.onPause();
    }

    protected void actualiser(Intent intent) {
       

    }
}
