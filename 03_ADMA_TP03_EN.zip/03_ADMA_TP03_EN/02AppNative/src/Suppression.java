package bib.com.gestionbibjson;


import android.app.Activity;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;


public class Suppression extends Activity {
	private Spinner spLivre;
	private Button btnSupprimer;
	private Button btnRetour;
	private ArrayAdapter<Livre> adpLivre;

	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.suppression);
		init();
	}

	private void init() {
		spLivre = (Spinner) findViewById(R.id.spLivre1);
		btnSupprimer = (Button) findViewById(R.id.btnSupprimer);
		btnRetour = (Button) findViewById(R.id.btnRetour);
		adpLivre = new ArrayAdapter<Livre>(this, android.R.layout.simple_list_item_1);
		adpLivre.setDropDownViewResource(android.R.layout.simple_list_item_1);
		spLivre.setAdapter(adpLivre);
		remplir();
		ajouterEcouteur();
	}

	private void remplir() {



	}



	private void ajouterEcouteur() {
		btnSupprimer.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				supprimerLivre();
			}
		});
		btnRetour.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				retourner();
			}
		});
	}

	protected void supprimerLivre() {

		
	}

	protected void retourner() {
		finish();
	}



}
