package bib.com.gestionbibjson;


import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;


public class Modification extends Activity {
	private Spinner spLivre;
	private EditText edTitre;
	private EditText edNbPage;
	private Button btnModifier;
	private Button btnRetour;
	private ArrayAdapter<Livre> adpLivre;

	protected void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.modification);
		init();
	}

	private void init() {
		spLivre = (Spinner) findViewById(R.id.spLivre2);
		edTitre = (EditText) findViewById(R.id.edTitre01);
		edNbPage = (EditText) findViewById(R.id.edNbPage01);
		btnModifier = (Button) findViewById(R.id.btnModifier);
		btnRetour = (Button) findViewById(R.id.btnRetour);
		adpLivre = new ArrayAdapter<Livre>(this, android.R.layout.simple_list_item_1);
		adpLivre.setDropDownViewResource(android.R.layout.simple_list_item_1);
		spLivre.setAdapter(adpLivre);
		remplir();
		ajouterEcouteur();
	}

	private void remplir() {


	}


	private void ajouterEcouteur() {
		// TODO Auto-generated method stub
		btnModifier.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				modifierLivre();

			}
		});
		btnRetour.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				retourner();

			}
		});

		spLivre.setOnItemSelectedListener(new OnItemSelectedListener() {

			@Override
			public void onItemSelected(AdapterView<?> arg0, View arg1, int arg2, long arg3) {
				actualiser();

			}

			@Override
			public void onNothingSelected(AdapterView<?> arg0) {

			}
		});
	}

	protected void actualiser() {

	}

	protected void retourner() {
		finish();
	}

	protected void modifierLivre() {

	}


}